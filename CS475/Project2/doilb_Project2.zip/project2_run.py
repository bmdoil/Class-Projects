#/usr/bin/env python3
#Author: Brent Doil
#Compiles and runs CS475 project2.cpp using 1,2,4 threads, static and dynamic schedule, coarse and fine grain 

from os import system
import multiprocessing



def main():
    results = "results.csv"
    proc = multiprocessing.cpu_count()
    with open(results, "a") as file:
        print("Have {} processors").format(proc)   
        file.write(("numbodies,numsteps,numthreads,omp_schedule,grain,megabodies_per_sec\n"))
    for threads in [1, 2, 4]:
        for schedule in ["static","dynamic"]:
            for x in range(0,10):
                compile = ("g++ -DNUMTHREADS={} -DSCHED={} project2.cpp -o project2 -lm -fopenmp").format(threads,schedule)
                system(compile)
                run = "./project2 {}".format(results)
                system(run)  
if __name__ == "__main__":
    main()